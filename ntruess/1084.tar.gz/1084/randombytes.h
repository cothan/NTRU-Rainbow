#include "randombytes.c"

void randombytes(unsigned char* x, unsigned long long xlen)