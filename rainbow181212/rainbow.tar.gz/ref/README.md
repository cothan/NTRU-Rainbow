# Rainbow181212

Rainbow181212 parameter set.

Test version for SUPERCOP, post-quantum cryptography. 

